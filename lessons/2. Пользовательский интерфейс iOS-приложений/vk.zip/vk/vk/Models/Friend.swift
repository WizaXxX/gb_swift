//
//  Friend.swift
//  vk
//
//  Created by WizaXxX on 01.06.2022.
//

import UIKit

struct Friend {
    var id: Int
    var name: String
    var image: UIImage
    var nickName: String
    var age: Int
}
